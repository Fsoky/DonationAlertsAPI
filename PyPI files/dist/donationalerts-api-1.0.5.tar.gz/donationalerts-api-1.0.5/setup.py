# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['donationalerts_api']
setup_kwargs = {
    'name': 'donationalerts-api',
    'version': '1.0.5',
    'description': 'https://github.com/Fsoky/Donation-Alerts-API-Python',
    'long_description': '# Donation-Alerts-API-Python\nThis module for python. With help this module, you can interact with API Donation Alerts\n\n    pip install donationalerts_api -U\n\n[PyPi](https://pypi.org/project/donationalerts-api/)\n\n[Official documentation Donation alerts API](https://www.donationalerts.com/apidoc)\n\n[Donation alerts application clients](https://www.donationalerts.com/application/clients)\n\n\n|Class|Description|\n|----------|-----------|\n|DonationAlertsApi(client_id, client_secret, redirect_uri, scope)|Request to API Donation Alerts|\n|Scopes|Has attributes for the instruction of scopes (USER_SHOW, DONATION_INDEX, DONATION_SUBSCRIBE, CUSTOM_ALERT_STORE, GOAL_SUBSCRIBE, POLL_SUBSCRIBE, ALL_SCOPES)|\n|Channels|Has attributes for the subscribe to channels (NEW_DONATION_ALERTS, DONATION_GOALS_UPDATES, POLLS_UPDATES, ALL_CHANNELS)|\n|Centrifugo(socket_connection_token, access_token, user_id)|Work with centrifugo|\n\n|Method|Description|\n|------|-----------|\n|login()|Returns link for connect to API|\n|get_code()|Returns code access application|\n|get_access_token(code)|Receive access token for the application (necessarily: transfer argument code which you got by get_code)|\n|get_donations(access_token)|Receive information about donate (messages)|\n|get_user(access_token)|Receive information about user|\n|send_custom_alert(access_token, external_id, headline, messages, image_url=None, sound_url=None, is_shown=0)|Send custom alert|\n|connect()|Connect to centrifugo websocket server|\n|subscribe(channels)|Subscribe to centrifugo channels|\n\n\n### Example:\n```py\nfrom flask import Flask, redirect\nfrom donationalerts_api import DonationAlertsApi, Centrifugo, Scopes, Channels\n\napp = Flask(__name__)\napi = DonationAlertsApi("client id", "client secret", "http://127.0.0.1:5000/login", Scopes.ALL_SCOPES)\n\n\n@app.route("/", methods=["get"])\ndef index():\n  return redirect(api.login())\n  \n\n@app.route("/login", methods=["get"])\ndef login():\n  code = api.get_code()\n  access_token = api.get_access_token(code)\n\n  user = api.get_user(access_token)\n\n  return user\n\nif __name__ == "__main__":\n  app.run(debug=True)\n```\n\n## Now you can pass list of scopes:\n\n```py\nfrom donationalerts_api import DonationAlertsApi, Scopes # New class: Scopes\n\nscopes = ["oauth-user-show", "oauth-donation-index", "oauth-poll-subscribe"] # Also right variant\napi = DonationAlertsApi("client id", "client secret", "redirect uri", [Scopes.USER_SHOW, Scopes.DONATION_INDEX]) # Or you can pass all scopes: Scopes.ALL_SCOPES\n```\n\n## Centrifugo, new events in real-time\n\n```py\nfrom flask import Flask, redirect\nfrom donationalerts_api import DonationAlertsApi, Centrifugo, Scopes, Channels\n\napp = Flask(__name__)\napi = DonationAlertsApi("client id", "client secret", "http://127.0.0.1:5000/login", Scopes.ALL_SCOPES)\n\n\n@app.route("/", methods=["get"])\ndef index():\n  return redirect(api.login())\n\n\n@app.route("/login", methods=["get"])\ndef login():\n  code = api.get_code()\n\n  access_token = api.get_access_token(code)\n  socket_token = api.get_user(access_token)["data"]["socket_connection_token"]\n  user_id = api.get_user(access_token)["data"]["id"]\n\n  fugo = Centrifugo(socket_token, access_token, user_id)\n  fugo.connect()\n\n  return fugo.subscribe([Channels.NEW_DONATION_ALERTS])\n\nif __name__ == "__main__":\n  app.run(debug=True)\n```',
    'author': 'Fsoky Community',
    'author_email': 'cyberuest0x12@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
