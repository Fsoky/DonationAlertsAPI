# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['donationalerts_api']
setup_kwargs = {
    'name': 'donationalerts-api',
    'version': '1.0.3',
    'description': 'https://github.com/Fsoky/Donation-Alerts-API-Python',
    'long_description': '# Donation-Alerts-API-Python\nThis module for python. With help this module, you can interact with API Donation Alerts\n\n    pip install donationalerts_api -U\n\n[PyPi](https://pypi.org/project/donationalerts-api/)\n\n[Official documentation Donation alerts API](https://www.donationalerts.com/apidoc)\n\n[Donation alerts application clients](https://www.donationalerts.com/application/clients)\n\n\n|Class|Description|\n|----------|-----------|\n|DonationAlertsApi(client_id, client_secret, redirect_uri, scope)|Request to API Donation Alerts|\n|Scopes|Has attributes for the instruction of scopes (user_show, donation_index, donation_subcribe, custom_alert_store, goal_subcribe, poll_subcribe, all_scopes)|\n\n|Method|Description|\n|------|-----------|\n|login()|Returns link for connect to API|\n|get_code()|Returns code access application|\n|get_access_token(code)|Receive access token for the application (necessarily: transfer argument code which you got by get_code)|\n|get_donations(access_token)|Receive information about donate (messages)|\n|get_user(access_token)|Receive information about user|\n|send_custom_alert(access_token, external_id, headline, messages, image_url=None, sound_url=None, is_shown=0)|Send custom alert|\n\n\n### Example:\n```py\nfrom flask import Flask, redirect\nfrom donationalerts_api import DonationAlertsApi, Scopes\n\nclient = Flask(__name__)\napi = DonationAlertsApi("9999", "a43f67k9920h01a2wdw", "http://127.0.0.1:5000/login", Scopes.all_scopes)\n\n\n@client.route("/", methods=["get"])\ndef index():\n  redirect(api.login())\n  \n\n@client.route("/login", methods=["get"])\ndef login():\n  code = api.get_code()\n  access_token = api.get_access_token(code)\n  \n  user = api.get_user(access_token)\n  donations = api.get_donations(access_token)\n  \n  api.send_custom_alert(access_token, 12, "Test headline", "Test something message...")\n  \n  return user\n  \n  \nif __name__ == "__main__":\n  client.run(debug=True)\n```\n\n## Now you can pass list of scopes:\n\n```py\nfrom donationalerts_api import DonationAlertsApi, Scopes # New class: Scopes\n\nscopes = ["oauth-user-show", "oauth-donation-index", "oauth-poll-subcribe"] # Also right variant\napi = DonationAlertsApi("client id", "client secret", "redirect uri", [Scopes.user_show, Scopes.donation_index]) # Or you can pass all scopes: Scopes.all_scopes\n```',
    'author': 'Fsoky Community',
    'author_email': 'cyberuest0x12@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
